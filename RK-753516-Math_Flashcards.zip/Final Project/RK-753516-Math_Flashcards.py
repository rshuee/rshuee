#Name: Risha Kansara
#Date: 01/08/2024
#File Name: RK-753516-Math_Flashcards
#Description: This program prompts the user with simple math questions
#               depending on the number of questions they want, and then
#               displays the score. The goal is to correctly answer 10
#               questions to save Princess Peach. The program will keep
#               track of the previous questions and display encouraging
#               messages. There will also different levels to choose from
#               to increase difficulty.

#_____________________________________________________________________________

#FUNCTION FOR LEVELS TO NEXT WINDOW - Once the button for the level is clicked,
#                                       a certain range will be selected and
#                                       the next screen will open.

def lvl1():
    global lvl_range
    lvl_range = 3 #Set range for the number values in math equation
    lbl_lvl_1.configure(bg='White')
    lbl_lvl_2.configure(bg='Light Green')
    lbl_lvl_3.configure(bg='Light Green')
    lbl_lvl_4.configure(bg='Light Green')
    
def lvl2():
    global lvl_range
    lvl_range = 6 #Set range for the number values in math equation
    lbl_lvl_2.configure(bg='White')
    lbl_lvl_1.configure(bg='Light Green')
    lbl_lvl_3.configure(bg='Light Green')
    lbl_lvl_4.configure(bg='Light Green')

def lvl3():
    global lvl_range
    lvl_range = 9 #Set range for the number values in math equation
    lbl_lvl_3.configure(bg='White')
    lbl_lvl_1.configure(bg='Light Green')
    lbl_lvl_2.configure(bg='Light Green')
    lbl_lvl_4.configure(bg='Light Green')

def lvl4():
    global lvl_range
    lvl_range = 12 #Set range for the number values in math equation
    lbl_lvl_4.configure(bg='White')
    lbl_lvl_1.configure(bg='Light Green')
    lbl_lvl_2.configure(bg='Light Green')
    lbl_lvl_3.configure(bg='Light Green')

#_____________________________________________________________________________

#FUNCTION FOR NEXT BUTTON - This button activates the game entirely and
#                           generates new questions based on the level.
#                           It will also keep track of the scores.

def next_button():
    global correct
    global wrong
    global total
    global num1
    global num2
    global operator
    global correct_answer
    global user_answer
    global equation
    global peach

    #Get the answer value from the user and add to the score
    try:
        user_answer = int(txt_answer.get()) #Gets input from entry box
        if operator == '+':
            correct_answer = num1 + num2 #Checks for correct answer
            equation = '-\n' + str(num1) + str(operator) + str(num2) + '=' +\
                       str(correct_answer) + ' | ' + str(user_answer) + '\n'
                        #Creates the equation and stores in variable
            
        elif operator == '-':
            correct_answer = num1 - num2 #Checks for correct answer
            equation = '-\n' + str(num1) + str(operator) + str(num2) + '=' +\
                       str(correct_answer) + ' | ' + str(user_answer) + '\n'
                        #Creates the equation and stores in variable
            
        elif operator == 'x':
            correct_answer = num1 * num2 #Checks for correct answer
            equation = '-\n' + str(num1) + str(operator) + str(num2) + '=' +\
                       str(correct_answer) + ' | ' + str(user_answer) + '\n'
                        #Creates the equation and stores in variable
            
        if user_answer == correct_answer:
            lbl_message.configure(text='Good job!')
            correct += 1 #Adds to correct score counter if correct
            total += 1 #Adds to total score counter
            
        else:
            lbl_message.configure(text='Try again!')
            wrong += 1 #Adds to wrong score counter if correct
            total += 1 #Adds to total score counter

    except:
        lbl_message.configure(text='Invalid input')
        equation = '-\nInvalid Input\n'

    #Generate Equation
    num1 = random.randint(1, lvl_range)
    lbl_num1.configure(text = num1) #Randomly generates number from level range

    num2 = random.randint(1, lvl_range)
    lbl_num2.configure(text = num2) #Randomly generates number from level range

    operator = random.choice('+-x')
    lbl_operator.configure(text = operator) #Randomly generates operator

    #Add values to the counter
    lbl_correct.configure(text='Correct: ' + str(correct))
    lbl_wrong.configure(text='Wrong: ' + str(wrong))
    lbl_total.configure(text='Total: ' + str(total))

    #Get the previous equation and add it to the history
    txt_history.insert(INSERT, equation)

    #Save princess peach from the answered questions
    if correct >= 10:
        lbl_peachtext.configure(text='Yay, you saved me!')
        lbl_peach.configure(image = peach, bg='Light Green')
    elif correct == 9:
        lbl_peachtext.configure(text='1 more to go!')
    elif correct == 8:
        lbl_peachtext.configure(text='2 more to go!')
    elif correct == 7:
        lbl_peachtext.configure(text='3 more to go!')
    elif correct == 6:
        lbl_peachtext.configure(text='4 more to go!')
    elif correct == 5:
        lbl_peachtext.configure(text='5 more to go!')
    elif correct == 4:
        lbl_peachtext.configure(text='6 more to go!')
    elif correct == 3:
        lbl_peachtext.configure(text='7 more to go!')
    elif correct == 2:
        lbl_peachtext.configure(text='8 more to go!')
    elif correct == 1:
        lbl_peachtext.configure(text='9 more to go!')

#_____________________________________________________________________________

#FUNCTION FOR RESET BUTTON - Sets the score to zero, clears history and
#                               resets original texts or images.

def reset():
    global correct
    global wrong
    global total
    global equation
    global peach_cage

    #Set all values to 0
    correct = 0
    wrong = 0
    total = 0
    #Change the score statements
    lbl_correct.configure(text='Correct: ' + str(correct))
    lbl_wrong.configure(text='Wrong: ' + str(wrong))
    lbl_total.configure(text='Total: ' + str(total))

    #Delete History
    txt_history.delete(0.0, END)

    #Reset Princess Peach imprisonment
    lbl_peachtext.configure(text='Answer 10 questions \nright & save me')
    lbl_peach.configure(image = peach_cage, bg='Light Green')

    #Reset Mario quotes
    lbl_message.configure(text='Press Next')
  
#_____________________________________________________________________________

#IMPORT LIBRARIES

from tkinter import *
from tkinter import scrolledtext
import random

#_____________________________________________________________________________

#VARIABLES - Used throughout the code

lvl_range = 3
correct = 0
wrong = 0
total = 0

#_____________________________________________________________________________

#CREATE START SCREEN GUI WINDOW - Display a welcome page with the levels

window = Tk()
window.title("Risha's Math Flashcards") #Create a title for the window
window.geometry('1000x500') #Set dimensions of the window
window.configure(bg='Light Green') #Change background colour of the window


#Welcome label to greet users
lbl_welcome = Label(window, text="Welcome to Risha's Math Flashcards"\
                    "\n-----------------------------------",\
                    font=('Courier New Bold', 25), bg='Light Green', fg='White')
lbl_welcome.place(x=150, y=10)
#bg sets the label background colour while fg sets the text colour


#Select the level using the buttons and labels
toad1 = PhotoImage(file='p15-c.png')
toad2 = PhotoImage(file='p15-b.png')
toad3 = PhotoImage(file='p15-a.png')
toad4 = PhotoImage(file='p15-d.png')

btn_lvl_1 = Button(window, image = toad1, bg='Green', command=lvl1)
btn_lvl_1.place(x=10, y=80)

btn_lvl_2 = Button(window, image = toad2, bg='Green', command=lvl2)
btn_lvl_2.place(x=80, y=80)

btn_lvl_3 = Button(window, image = toad3, bg='Green', command=lvl3)
btn_lvl_3.place(x=155, y=80)

btn_lvl_4 = Button(window, image = toad4, bg='Green', command=lvl4)
btn_lvl_4.place(x=214, y=80)

lbl_lvl_1 = Label(window, text='1', font=('Courier New', 10),\
                  bg='White', fg='Green')
lbl_lvl_1.place(x=35, y=150)


lbl_lvl_2 = Label(window, text='2', font=('Courier New', 10),\
                  bg='Light Green', fg='Green')
lbl_lvl_2.place(x=105, y=150)


lbl_lvl_3 = Label(window, text='3', font=('Courier New', 10),\
                  bg='Light Green', fg='Green')
lbl_lvl_3.place(x=170, y=150)


lbl_lvl_4 = Label(window, text='4', font=('Courier New', 10),\
                  bg='Light Green', fg='Green')
lbl_lvl_4.place(x=239, y=150)


#Create widgets for the math flashcards, including buttons, labels & entry box
lbl_num1 = Label(window, text='?', font=('Courier New', 50),\
                  bg='White', fg='Green')
lbl_num1.place(x=400, y=170)


lbl_num2 = Label(window, text='?', font=('Courier New', 50),\
                  bg='White', fg='Green')
lbl_num2.place(x=600, y=170)


lbl_operator = Label(window, text='?', font=('Courier New', 50),\
                  bg='White', fg='Green')
lbl_operator.place(x=500, y=170)

btn_next = Button(window, text='Next', font=('Courier New', 15),\
                    bg='Green', fg='Light Green', command=next_button)
btn_next.place(x=490, y=320)

txt_answer = Entry(window, width=10, font=('Courier New', 30))
txt_answer.place(x=400, y=260)


#Add widgets for Mario's quotes and messages using labels
mario_img = PhotoImage(file='mario.png')

lbl_mario = Label(window, image = mario_img, bg='Light Green')
lbl_mario.place(x=850, y=400)

lbl_message = Label(window, text='Press Next', font=('Courier New Bold', 15),\
                    bg='Light Green', fg='Green')
lbl_message.place(x=800, y=350)


#Widgets for the score board
lbl_correct = Label(window, text='Correct: ' + str(correct),\
                    font=('Courier New', 15), bg='Light Green', fg='White')
lbl_correct.place(x=350, y=400)


lbl_wrong = Label(window, text='Wrong: ' + str(wrong),\
                    font=('Courier New', 15), bg='Light Green', fg='White')
lbl_wrong.place(x=550, y=400)


lbl_total = Label(window, text='Total: ' + str(total),\
                    font=('Courier New', 15), bg='Light Green', fg='White')
lbl_total.place(x=375, y=440)


btn_reset = Button(window, text='Reset', font=('Courier New', 12),\
                   bg='White', fg='Green', command=reset)
btn_reset.place(x=580, y=440)


#Add scrolledtext content to add previous questions and answers
txt_history = scrolledtext.ScrolledText(window, width=20, height=10, \
                                        font=('Courier New', 15))
txt_history.place(x=10, y=240)

lbl_history = Label(window, text='HISTORY',font=('Courier New Bold', 15),\
                    bg='Light Green', fg='White')
lbl_history.place(x=10, y=200)


#Create Princess Peach label
peach_cage = PhotoImage(file='peach_cage.png')
peach = PhotoImage(file='peach.png')

lbl_peach = Label(window, image = peach_cage, bg='Light Green')
lbl_peach.place(x=850, y=100)

lbl_peachtext = Label(window, text='Answer 10 questions \nright & save me'\
                    , font=('Courier New', 15), bg='Light Green', fg='Green')
lbl_peachtext.place(x=750, y=200)



txt_answer.focus() #Set cursor to entry box

window.mainloop()
#_____________________________________________________________________________

